#include <Arduino.h>

#define NOTE_D6 1175

#define BUZZER_PIN 3

void setup() {
  pinMode(BUZZER_PIN, OUTPUT);
}

void loop() {
  // Play the bell note
  tone(BUZZER_PIN, NOTE_D6, 1000);
  delay(1200);

  // Play the echo
  tone(BUZZER_PIN, NOTE_D6, 500);
  delay(600);

  // Pause before the next bell toll
  delay(2000);
}