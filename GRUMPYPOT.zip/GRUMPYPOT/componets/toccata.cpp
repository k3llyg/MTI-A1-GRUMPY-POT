#include <Arduino.h>

#define NOTE_A 440
#define NOTE_G 392
#define NOTE_F 349
#define NOTE_E 330
#define NOTE_D 294
#define NOTE_CS 277

#define buzzer_pin 3 // old pin 3 for buzzer agaaain


int melody1[] = {
  NOTE_A, NOTE_G, NOTE_A, NOTE_G, NOTE_F, NOTE_E, NOTE_D, NOTE_CS, NOTE_D
};

int noteDurations1[] = {
  4, int(8/0.8), 1, int(4/0.3), int(4/0.3), int(4/0.3), int(4/0.3), int(4/0.3), 2
};

int melody2[] = {
  // 2nd melody
  NOTE_A
};

int noteDurations2[] = {
  // 2nd melody rythmn
  1

};




void setup() {
  pinMode(buzzer_pin, OUTPUT);
}



void mp3Threat() {
  // Play 1st melody
  for (int i = 0; i < 9; i++) {
    int noteDuration = 1000/noteDurations1[i];
    tone(buzzer_pin, melody1[i], noteDuration);
    int pauseBetweenNotes = noteDuration * 1.30;
    delay(pauseBetweenNotes);
    noTone(buzzer_pin);
  }
  delay(2000);
}



void loop() {
  //loop this function
  mp3Threat();
}
